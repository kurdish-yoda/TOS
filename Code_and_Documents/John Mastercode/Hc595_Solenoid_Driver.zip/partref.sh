#!/bin/bash

python partref.py "Hc595_Solenoid_Driver.kicad_pcb" 131 12 88 12 29 4 37 4 22 1
